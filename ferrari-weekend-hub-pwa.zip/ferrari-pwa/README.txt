SCUDERIA FERRARI · WEEKEND HUB — PWA

Questa cartella contiene una versione installabile come app della pagina HTML.

INSTALLAZIONE SU ANDROID/SAMSUNG:
1. Pubblica questa cartella su un servizio che la serva in HTTPS.
2. Apri l'indirizzo con Chrome o Samsung Internet.
3. Usa il menu del browser → "Installa app" / "Aggiungi alla schermata Home".
4. Avrai Ferrari Hub come app separata sulla Home.

NOTA:
Una vera app/widget Android (.apk) richiede un progetto Android compilato. Questa PWA è la strada più semplice per ottenere subito un'app Home-screen senza riscrivere tutto il codice.
